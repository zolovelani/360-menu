import React from 'react'

const ApplicationContext = React.createContext()


export default ApplicationContext
