import React,{ useContext } from 'react'
import ApplicationContext from '../../context/Application'


const Products = () => {
  const {activeCategory, products, setActiveProduct} = useContext(ApplicationContext)
  console.log(products);
  return(
  // TODO: get activeCategory from context to display headline
  // TODO: get activeCategory from context to filter products
  // TODO: add setActiveProduct from context to buttons to open modal
  // TODO: this component only sets up logic, all data
  //       should be passed to components using props which makes it easier
  //       to include presentational components in storybook without logic
  <div>
    <h1>{activeCategory.name}Menu</h1>
    {/* TODO: those cards should be created dynamically by filtering all products */}
  {products.filter(product => product.category.includes(activeCategory.id))
  .map(product => (
    <div onClick={() => setActiveProduct(product)} key={product.id}>
      {product.name}Product Card Component
      </div>
    ))}
  </div>
  )
}

export default Products
