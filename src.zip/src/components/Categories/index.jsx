import React, {useContext} from 'react'
import ApplicationContext from '../../context/Application'

const Categories = () => {
  const { categories, setActiveCategory, activeCategory } = useContext(ApplicationContext)
  return ( 

  // DONE: get categories from context and create buttons
  // DONE: get activeCategory from context and highlight active category
  // DONE: add setActiveCategory from context to buttons
  // TODO: this component only sets up logic, all data
  //       should be passed to components using props which makes it easier
  //       to include presentational components in storybook without logic
  <div>
    {/* TODO: those buttons should be created dynamically */}
    {categories.map(category => (
      // TODO: this should be a CatagoryButton component
      // should be something like <CatagoryButton catagory=
        /* {catagory} activive={category.id} === activeCategory.id/> */
        <button 
        type="button"
        key={category.id} 
        onClick={() => setActiveCategory(category)}
        disabled={!category.Products}
        style={{border: `1px solid ${
          category.id === activeCategory.id ? 'hotpink' : 'transparent' }`}}
        >
          {category.name} placeholder</button>
      ))}
  </div>  
  )   
}

export default Categories
