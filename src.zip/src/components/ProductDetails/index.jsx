import React, {useContext, useState} from 'react'
import ApplicationContext from '../../context/Application'

const ProductDetails = () => {
  const [selectedOption, setSelectedOption] = useState({})
  const {activeProduct, setActiveProduct, activeCategory, addToOrders,
  } = useContext(ApplicationContext)

  if (!activeProduct?.name) {
    return null
  }
  return(
  // TODO: get activeProduct from context to display product details
  // TODO: add setActiveProduct from context to buttons to close modal and discard activeProduct
  // TODO: set up options state locally and pass resulting
  // TODO: add addProductToOrder function to add current product to order list with comments and options and price
  // TODO: this component only sets up logic, all data
  //       should be passed to components using props which makes it easier
  //       to include presentational components in storybook without logic
  <div>
    {/* product component */}
    product image
   {/*<pre>{JSON.stringify(activeProduct, null, 2)}</pre>*/}
   {/*<pre>{JSON.stringify(activeProduct,null,2)}</pre>*/}
   {activeProduct?.images?.[0]?.thumbnails.large.url ?(
     <img 
     src={activeProduct?.images?.[0]?.thumbnails.large.url}
     alt={activeProduct.name} 
     />
   ) : ( <div>should show placeholder using{activeCategory.icon}</div>
   )}
    <br />
    <h2>{activeProduct.name}</h2>
    <br />
    {activeProduct.description}

    {activeProduct.options ? (
      <div>
        {activeProduct.options.map(({ option, price }) => (
          <label htmlFor={option}>
            <input 
            onChange={()=> setSelectedOption({option, price})}
            type="radio" 
            key={option} 
            name="options" 
            id={option} 
            value={{option,price}}/>
            {option} {price}
          </label>

        ))}
        </div>
   ) : null}
    <br />
    <button type="button" onClick={() => setActiveProduct({})}>
      close overlay
    </button>

    <button 
    type="button"
    onClick={() => {
      addToOrders({ ...activeProduct, selectedOption})
      setActiveProduct({})
    }}>
      add to order
    </button>
  </div>
  )
}

export default ProductDetails
