import React from 'react'

const Sidebar = ({ children }) => <div>{children}</div>

export default Sidebar
