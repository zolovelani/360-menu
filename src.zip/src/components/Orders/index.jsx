import React, {useContext} from 'react'
import ApplicationContext from '../../context/Application'
const Orders = () => {
  const {orders, addToOrders, removeOrderAtIndex, setActiveProduct } = useContext(ApplicationContext)

  // ORDERS SHOULD HAVE A STATE OR A TYPE:
  // Current (notin kitchen, can still make changes- have not presse ORDER BUTTON)
  // Active (sent to kitchen order should et  type to active)
  // PAST (order been deliverd to ur table)
  return (
  // TODO: get orders and filter by type
  // TODO: get removeOrder function to remove an item from
  // TODO: get dupelicateOrder function to duplicate item from
  // TODO: this component only sets up logic, all data
  //       should be passed to components using props which makes it easier
  //       to include presentational components in storybook without logic
  <div>
    
    {/* TODO: those orders should be created dynamically and filtered by state */}
    {/* should actually have three lists of items here, displaying the orders, depending on the list */}
    {orders.map((order, index) => (
    <div key={`order_${order.id}`}>
      {order.name} entry component &bull; {order.selectedOption?.option}
    <button type="button" onClick={() => removeOrderAtIndex(index)}>🗑</button>
    <button type="button" onClick={() => addToOrders(order)}>🔁</button>
    <button type="button" onClick={() => setActiveProduct(order)}>✏️</button>
  </div>
    ))}
  </div>  
  )
}

export default Orders
